import{b as r}from"./graph-BMvyBiHy.js";var e=4;function a(o){return r(o,e)}export{a as c};
