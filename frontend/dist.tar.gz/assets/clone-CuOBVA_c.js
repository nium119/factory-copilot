import{b as r}from"./graph-Bj0l6poL.js";var e=4;function a(o){return r(o,e)}export{a as c};
