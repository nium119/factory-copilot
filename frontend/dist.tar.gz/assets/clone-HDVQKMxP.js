import{b as r}from"./graph-Dvcq3bFs.js";var e=4;function a(o){return r(o,e)}export{a as c};
