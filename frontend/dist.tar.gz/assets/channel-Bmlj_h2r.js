import{aq as o,ar as n}from"./mermaid.core-DbP27z_8.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
