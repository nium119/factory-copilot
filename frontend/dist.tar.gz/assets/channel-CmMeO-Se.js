import{aq as o,ar as n}from"./mermaid.core-mmnP4Cs1.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
