import{b as r}from"./graph-AUWBZMly.js";var e=4;function a(o){return r(o,e)}export{a as c};
